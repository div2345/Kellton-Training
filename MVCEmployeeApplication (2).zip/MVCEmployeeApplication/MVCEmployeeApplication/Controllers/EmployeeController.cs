﻿using Microsoft.AspNetCore.Mvc;
using MVCEmployeeApplication.Models;
using System;
using System.Collections.Generic;
using System.Net.Http;

namespace MVCEmployeeApplication.Controllers
{
    public class EmployeeController : Controller
    {
        string Baseurl;
        private List<EmployeeData> GetApIHit(string Baseurl)
        {
            List<EmployeeData> EmpInfo = new List<EmployeeData>();

            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(Baseurl);
                var responseTask = client.GetAsync(Baseurl);
                responseTask.Wait();
                var result = responseTask.Result;
                if (result.IsSuccessStatusCode)
                {
                    var readTask = result.Content.ReadAsAsync<List<EmployeeData>>();
                    readTask.Wait();
                    EmpInfo = readTask.Result;
                }
                return EmpInfo;
            }

        }
        private EmployeeData GetApIHit(string Baseurl, int id, EmployeeData employee)
        {
            EmployeeData EmpInfo = new EmployeeData();
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(Baseurl);
                if (employee == null && id != 0)
                {
                    var responseTask = client.GetAsync(requestUri: "?id=" + id);
                    responseTask.Wait();
                    var result = responseTask.Result;
                    if (result.IsSuccessStatusCode)
                    {
                        var readTask = result.Content.ReadAsAsync<EmployeeData>();
                        readTask.Wait();
                        EmpInfo = readTask.Result;
                    }
                    return EmpInfo;
                }
                else
                {
                    var responseTask = client.PostAsJsonAsync<EmployeeData>(Baseurl, employee);
                    responseTask.Wait();
                    var result = responseTask.Result;
                    if (result.IsSuccessStatusCode)
                    {
                        var readTask = result.Content.ReadAsAsync<EmployeeData>();
                        readTask.Wait();
                        EmpInfo = readTask.Result;
                    }
                    return EmpInfo;
                }
            }
        }

        public ActionResult Index()
        {
            Baseurl = "http://localhost:59594/api/Employee/ViewEmployee";
            List<EmployeeData> EmpInfo = new List<EmployeeData>();
            EmpInfo = GetApIHit(Baseurl);
            return View(EmpInfo);
        }

        [HttpGet]
        public ActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Create(EmployeeData employee)
        {
            Baseurl = "http://localhost:59594/api/Employee/Insert";
            EmployeeData EmpInfo = new EmployeeData();
            EmpInfo = GetApIHit(Baseurl, 0, employee);
            return View(employee);
        }


        [HttpGet]
        public ActionResult Edit(int id)
        {
            Baseurl = "http://localhost:59594/api/Employee/SrchEmployee";
            EmployeeData EmpInfo = new EmployeeData();
            EmpInfo = GetApIHit(Baseurl, id,null);
            return View(EmpInfo);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int id, EmployeeData employee)
        {
            Baseurl = "http://localhost:59594/api/Employee/UpdateEmployee";
            EmployeeData EmpInfo = new EmployeeData();
            EmpInfo = GetApIHit(Baseurl, 0, employee);
            return RedirectToAction("Index");
        }

        [HttpGet]
        public ActionResult Delete(int id)
        {
            Baseurl = "http://localhost:59594/api/Employee/SrchEmployee";
            EmployeeData EmpInfo = new EmployeeData();            
            EmpInfo = GetApIHit(Baseurl, id, null);
            return View(EmpInfo);           
        }

        [HttpPost, ActionName("Delete")]
        public ActionResult DeleteConfirmed(int id)
        {
            Baseurl = "http://localhost:59594/api/Employee/DltEmployee";
            EmployeeData EmpInfo = new EmployeeData();
            EmpInfo = GetApIHit(Baseurl, id, null);
            return RedirectToAction("Index");          
        }
    }
}