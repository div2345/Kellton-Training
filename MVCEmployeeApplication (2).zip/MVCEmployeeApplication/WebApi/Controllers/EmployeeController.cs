﻿using DataLayer;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace WebApi.Controllers
{
    [Route("api/Employee/[action]")]
    [ApiController]
    public class EmployeeController : ControllerBase
    {
        private SqlHandler objemployee = new SqlHandler();
        
        public  ActionResult <List<Employee>> ViewEmployee()
        {                            
            DataTable dtResult= objemployee.ExecuteDDLProcedure("USP_GetAllEmployees", null);
            List<Employee> lstEmployee = new List<Employee>();
            Employee employee;

            foreach (DataRow drEmployee in dtResult.Rows)
            {
                employee = new Employee();

                employee.ID = Convert.ToInt32(drEmployee["EmployeeID"]);
                employee.Name = drEmployee["Name"].ToString();
                employee.Gender = drEmployee["Gender"].ToString();
                employee.Department = drEmployee["Department"].ToString();
                employee.City = drEmployee["City"].ToString();

                lstEmployee.Add(employee);
            }

            return lstEmployee;
        }
        
        public ActionResult<Employee> UpdateEmployee(Employee employee)
        {
            SqlHandler objemployee = new SqlHandler();
          
            SqlParameter[] sqlParameter = new SqlParameter[5];
            sqlParameter[0] = new SqlParameter("@EmpId", employee.ID);
            sqlParameter[1] = new SqlParameter("@Name", employee.Name);
            sqlParameter[2] = new SqlParameter("@Gender", employee.Gender);
            sqlParameter[3] = new SqlParameter("@Department", employee.Department);
            sqlParameter[4] = new SqlParameter("@City", employee.City);

            objemployee.ExecuteDMLProcedure("USP_UpdateEmployee", sqlParameter);
            
            return employee;
        }
      
        public ActionResult<Employee> SrchEmployee(int id)
        {
            SqlHandler objemployee = new SqlHandler();

            SqlParameter[] sqlParameter = new SqlParameter[1];
            sqlParameter[0] = new SqlParameter("@EmpID", id);

            DataTable dtResult = objemployee.ExecuteDDLProcedure("USP_SearchEmployee", sqlParameter);
            List<Employee> lstEmployee = new List<Employee>();
            Employee employee = new Employee();

            foreach (DataRow drEmployee in dtResult.Rows)
            {
                employee = new Employee();

                employee.ID = Convert.ToInt32(drEmployee["EmployeeID"]);
                employee.Name = drEmployee["Name"].ToString();
                employee.Gender = drEmployee["Gender"].ToString();
                employee.Department = drEmployee["Department"].ToString();
                employee.City = drEmployee["City"].ToString();

                lstEmployee.Add(employee);
            }
            return employee;
        }
        
        public ActionResult<Employee> DltEmployee(int id)
        {
            SqlHandler objemployee = new SqlHandler();
            Employee employee = new Employee();

            SqlParameter[] sqlParameter = new SqlParameter[1];
            sqlParameter[0] = new SqlParameter("@EmpId", id);           
            objemployee.ExecuteDDLProcedure("USP_DeleteEmployee", sqlParameter);

            return employee;
        }
      
        public ActionResult<Employee> Insert(Employee employee)
        {
            SqlHandler objemployee = new SqlHandler();
            SqlParameter[] sqlParameter = new SqlParameter[4];
            sqlParameter[0] = new SqlParameter("@Name", employee.Name);
            sqlParameter[1] = new SqlParameter("@Gender", employee.Gender);
            sqlParameter[2] = new SqlParameter("@Department", employee.Department);
            sqlParameter[3] = new SqlParameter("@City", employee.City);

            objemployee.ExecuteDMLProcedure("USP_InsertEmployee", sqlParameter);
            return employee;
        }
    }
}