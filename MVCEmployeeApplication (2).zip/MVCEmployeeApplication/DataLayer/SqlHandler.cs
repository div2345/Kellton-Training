﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace DataLayer
{
    public class SqlHandler
    {
        readonly string connectionString = "Data Source=KELLGGNCPU0348;Initial Catalog = Employeedetails;Integrated Security=SSPI;";
        private SqlConnection sqlConnection;

        private void OpenConnection()
        {
            if(sqlConnection == null)
            {
                sqlConnection = new SqlConnection(connectionString);
                sqlConnection.Open();
            }
        }

        private void CloseConnection()
        {
            if(sqlConnection.State == ConnectionState.Open)
            {
                sqlConnection.Close();
            }
        }

        public void ExecuteDMLProcedure(string procedureName, SqlParameter[] sqlParameters)
        {
            using (SqlConnection sqlConnection = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand(procedureName,sqlConnection)
                {
                    CommandType = CommandType.StoredProcedure
                };

                cmd.Parameters.Clear();
                cmd.Parameters.AddRange(sqlParameters);

                sqlConnection.Open();
                cmd.ExecuteNonQuery();
                sqlConnection.Close();

            }
        }
        
        public DataTable ExecuteDDLProcedure(string procedureName, SqlParameter[] sqlParameters)
        {
            DataTable dtResult = new DataTable();
            OpenConnection();

            SqlCommand sqlCommand = new SqlCommand(procedureName, sqlConnection);
            sqlCommand.CommandType = CommandType.StoredProcedure;

            if(sqlParameters != null && sqlParameters.Length > 0)
            {
                sqlCommand.Parameters.Clear();
                sqlCommand.Parameters.AddRange(sqlParameters);
            }

            SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(sqlCommand);

            sqlDataAdapter.Fill(dtResult);

            CloseConnection();
            return dtResult;
        }

    }
}
