﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace RecruitmentWebApplication.Models
{
    public class UserScoreView
    {
        public int UserScoreId { get; set; }
        public int UserId { get; set; }
        public int CourseId { get; set; }

        [Range(1, 99, ErrorMessage = "Range Must be between 1 to 99")]
        public int Marks { get; set; }
       [Range(1, 99, ErrorMessage = "Range Must be between 1 to 99")]
        
        //[RegularExpression("^(?:99|[1 - 9]?[1 - 9])*$", ErrorMessage = "Entered format is not valid.")]
        public List<int> MarksList { get; set; }
        public List<int> CourseIdList { get; set; }
        public string CourseName { get; set; }
        public List<string> CourseNameList { get; set; }
    }
}
