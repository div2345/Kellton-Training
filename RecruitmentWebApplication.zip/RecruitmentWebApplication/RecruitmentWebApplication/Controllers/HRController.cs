﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using RecruitmentWebApplication.Models;

namespace RecruitmentWebApplication.Controllers
{
    public class HRController : Controller
    {
        string baseurl;
        private List<UserModel> GetApIHit(string baseurl , string tokent)
        {
            List<UserModel> lstUserModel = new List<UserModel>();
            UserModel userModel = new UserModel();
            using (var client = new HttpClient())
            {
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", tokent);
                client.BaseAddress = new Uri(this.baseurl);
                var responseTask = client.GetAsync(baseurl);
                responseTask.Wait();
                var result = responseTask.Result;
                if (result.StatusCode == System.Net.HttpStatusCode.OK)
                {
                    var readTask = result.Content.ReadAsAsync<List<UserModel>>();
                    readTask.Wait();
                    lstUserModel = readTask.Result;
                   
                }
                else if (result.StatusCode == System.Net.HttpStatusCode.Unauthorized)
                {
                    userModel.Error = "Un Authorize";
                    lstUserModel.Add(userModel);

                }
            }
            return lstUserModel;

        }
        private UserModel ApIHit(string baseurl, int UserID, string tokent)
        {
            UserModel userModel = new UserModel();
            using (var client = new HttpClient())
            {
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", tokent);
                client.BaseAddress = new Uri(this.baseurl);
                var responseTask = client.GetAsync(requestUri: "?UserID=" + UserID);
                responseTask.Wait();
                var result = responseTask.Result;
                if (result.IsSuccessStatusCode)
                {
                    var readTask = result.Content.ReadAsAsync<UserModel>();
                    readTask.Wait();
                    userModel = readTask.Result;
                }
                else if (result.StatusCode == System.Net.HttpStatusCode.Unauthorized)
                {
                    userModel.Error = "Un Authorize";
                    
                }
                return userModel;
            }

        }
        private List<UserScoreView> GetApIHit(string baseurl, int UserID, string tokent)
        {
            List<UserScoreView> score = new List<UserScoreView>();
            UserScoreView userScore = new UserScoreView();
            using (var client = new HttpClient())
            {
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", tokent);
                client.BaseAddress = new Uri(this.baseurl);
                var responseTask = client.GetAsync(requestUri: "?UserID=" + UserID);
                responseTask.Wait();
                var result = responseTask.Result;
                if (result.IsSuccessStatusCode)
                {
                    var readTask = result.Content.ReadAsAsync<List<UserScoreView>>();
                    readTask.Wait();
                    score = readTask.Result;
                }
                else if (result.StatusCode == System.Net.HttpStatusCode.Unauthorized)
                {

                    score = null;
                }
                return score;
            }

        }

        public ActionResult Index(UserModel user)
        {
            var tokent = HttpContext.Session.GetString("sessionForToken");
            List<UserModel> userModel = new List<UserModel>();
            baseurl = "http://localhost:60574/api/HR/GetDetail";
            userModel = GetApIHit(baseurl, tokent);
            
            return View(userModel);

        }
        [HttpGet]
        public ActionResult <List<UserScoreView>> ShowResult(int UserID)
        {
            var tokent = HttpContext.Session.GetString("sessionForToken");
            List<UserScoreView> score = new List<UserScoreView>();
            UserScoreView userScore = new UserScoreView();
            baseurl = "http://localhost:60574/api/HR/ShowResult";
            score = GetApIHit(baseurl,UserID, tokent);
            
            return View(score);
        }

        [HttpGet]
        public ActionResult <UserModel> Accept(int UserID)
        {
            var tokent = HttpContext.Session.GetString("sessionForToken");
            UserModel userModel = new UserModel();
            baseurl = "http://localhost:60574/api/Candidate/GetEmployee";
            userModel = ApIHit(baseurl, UserID,tokent);
            if (userModel.Error == null)
                return View(userModel);
            else
                return Content("Un Authorized");

        }
        [HttpPost, ActionName("Accept")]
        public ActionResult<float> AcceptCandidate(int UserID)
        {
            var tokent = HttpContext.Session.GetString("sessionForToken");
            baseurl = "http://localhost:60574/api/TechinalInterviewer/InterviewState";
            GetApIHit(baseurl, UserID, tokent);

            return RedirectToAction("Index", new { UserID = UserID });    
        }

        [HttpGet]
        public ActionResult<UserModel> Reject(int UserID)
        {

            var tokent = HttpContext.Session.GetString("sessionForToken");
            UserModel userModel = new UserModel();
            baseurl = "http://localhost:60574/api/Candidate/GetEmployee";
            userModel = ApIHit(baseurl, UserID, tokent);
            if (userModel.Error == null)
                return View(userModel);
            else
                return Content("Un Authorized");
        }

        [HttpPost, ActionName("Reject")]
        public ActionResult<float> RejectCandidate(int UserID)
        {
            var tokent = HttpContext.Session.GetString("sessionForToken");
            baseurl = "http://localhost:60574/api/TechinalInterviewer/InterviewState";
            GetApIHit(baseurl, UserID, tokent);
            GetApIHit(baseurl, UserID, tokent);
            return RedirectToAction("Index", new { UserID = UserID });
        }
    }
}