﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using RecruitmentWebApplication.Models;
using System;
using System.IO;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Net.Mail;
using System.Security.Cryptography;
using System.Text;

namespace RecruitmentWebApplication.Controllers
{

    public class AccountController : Controller
    {
        private readonly ISession session = null;
        public AccountController(IHttpContextAccessor httpContextAccessor)
        {
            this.session = httpContextAccessor.HttpContext.Session;
        }

        string Baseurl;
        string url = "http://localhost:60574/api/Authorization/token";
        string token;
        private string GetToken(string url, UserModel login)
        {
            token = string.Empty;
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(url);
                var responseTask = client.PostAsJsonAsync(url, login);
                responseTask.Wait();
                var result = responseTask.Result;
                if (result.IsSuccessStatusCode)
                {
                    var readTask = result.Content.ReadAsStringAsync();
                    readTask.Wait();
                    token = readTask.Result;
                }
                return token;
            }
        }

        

        private UserModel GetApIHit(string Baseurl, UserModel user, string token)
        {
            UserModel userModel = new UserModel();

            using (var client = new HttpClient())
            {
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
                client.BaseAddress = new Uri(Baseurl);
                var responseTask = client.PostAsJsonAsync(Baseurl, user);
                responseTask.Wait();
                var result = responseTask.Result;
                if (result.StatusCode == HttpStatusCode.OK)
                {
                    var readTask = result.Content.ReadAsAsync<UserModel>();
                    readTask.Wait();
                    userModel = readTask.Result;
                    return userModel;
                }

                else if (result.StatusCode == HttpStatusCode.BadRequest)
                {
                    userModel.Error = "Bad Request";
                    return userModel;
                }
                else if (result.StatusCode == HttpStatusCode.Unauthorized)
                {
                    userModel.Error = "User UnAuthorized";
                    return userModel;
                }

            }
            return userModel;

        }
       
        public ActionResult Login()
        {
            LoginModel loginModel = new LoginModel();
            return View(loginModel);
        }

        [HttpPost]
        public ActionResult Login(UserModel login)
        {

            Baseurl = "http://localhost:60574/api/Account/Login";
            UserModel userModel = new UserModel();
            LoginModel loginModel = new LoginModel();
            token = GetToken(url, login);
           // string UserIdString = userModel.UserID.ToString();
            userModel = GetApIHit(Baseurl, login,token);
            loginModel.Error = userModel.Error;
            session.SetString("sessionForName", "Welcome " + userModel.Name);
            session.SetString("SessionKeyName", "Done");
            session.SetString("sessionForToken", token);
            session.SetString("sessionForUserID", userModel.UserID.ToString());

            //string tokent = this.session.GetStrin
            var name = this.session.GetString("SessionKeyName");
            var sessionname = this.session.GetString("sessionForName");

            if (userModel.RoleId == 1)
            {
                return RedirectToAction("Index", "Candidate", new {  userModel.UserID });
            }
            else if (userModel.RoleId == 2)
            {
                return RedirectToAction("Index", "TechnicalInterviewer", new { userModel.UserID });
            }
            else if (userModel.RoleId == 3)
                return RedirectToAction("Index", "HR", new { userModel.UserID });
            else
                return Content("Un Authorized");
        }
      
        public ActionResult Register()
        {
            RegisterModel registerModel = new RegisterModel();
            return View(registerModel);
        }
        [HttpPost]
        public ActionResult Register(UserModel register)
        {
            var tokent = HttpContext.Session.GetString("sessionForToken");
            string password = GeneratePassword().ToString();

            string encrypt = string.Empty;
            encrypt = Encrypt(password);
            register.Password = encrypt;
            string email = register.Email;
            Baseurl = "http://localhost:60574/api/Account/Register";
            UserModel userModel = new UserModel();
            userModel = GetApIHit(Baseurl, register, tokent);
            if (userModel.Error != null)
            {
              
                return Content("Email Already Registered");
                //return View("RegisterError");
            }
            else
            {
                SendPassword(password, email);
                return RedirectToAction("Login");
            }
        }
        protected string SendPassword(string pass,string email)
        {
            string strNewPassword = pass;
            MailMessage message = new MailMessage();
            SmtpClient smtp = new SmtpClient();
            message.From = new MailAddress("divyansh.singh@kelltontech.com");
            message.To.Add(new MailAddress("divyansh.singh@kelltontech.com"));
            message.Subject = "Password";
            message.IsBodyHtml = true; //to make message body as html  
            message.Body = strNewPassword;
            smtp.Port = 587;
            smtp.Host = "smtp.gmail.com"; //for gmail host  
            smtp.EnableSsl = true;
            smtp.UseDefaultCredentials = false;
            smtp.Credentials = new NetworkCredential("divyansh.singh@kelltontech.com", "Dsingh0211@");
            smtp.DeliveryMethod = SmtpDeliveryMethod.Network;
            smtp.Send(message);
            return strNewPassword;

        }
        public string GeneratePassword()
        {
            string PasswordLength = "8";
            string NewPassword = "";

            string allowedChars = "";
            allowedChars = "1,2,3,4,5,6,7,8,9,0";
            allowedChars += "A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,";
            allowedChars += "a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,";


            char[] sep = {
            ','
        };
            string[] arr = allowedChars.Split(sep);


            string IDString = "";
            string temp = "";

            Random rand = new Random();

            for (int i = 0; i < Convert.ToInt32(PasswordLength); i++)
            {
                temp = arr[rand.Next(0, arr.Length)];
                IDString += temp;
                NewPassword = IDString;

            }
            return NewPassword;
        }
        public ActionResult LogOut()
        {
            this.session.Clear();
            return RedirectToAction("login", "Account");
        }
        
        private string Encrypt(string clearText)
        {
            string EncryptionKey = "MAKV2SPBNI99212";
            byte[] clearBytes = Encoding.Unicode.GetBytes(clearText);
            using (Aes encryptor = Aes.Create())
            {
                Rfc2898DeriveBytes pdb = new Rfc2898DeriveBytes(EncryptionKey, new byte[] { 0x49, 0x76, 0x61, 0x6e, 0x20, 0x4d, 0x65, 0x64, 0x76, 0x65, 0x64, 0x65, 0x76 });
                encryptor.Key = pdb.GetBytes(32);
                encryptor.IV = pdb.GetBytes(16);
                using (MemoryStream ms = new MemoryStream())
                {
                    using (CryptoStream cs = new CryptoStream(ms, encryptor.CreateEncryptor(), CryptoStreamMode.Write))
                    {
                        cs.Write(clearBytes, 0, clearBytes.Length);
                        cs.Close();
                    }
                    clearText = Convert.ToBase64String(ms.ToArray());
                }
            }
            return clearText;
        }
    }
}