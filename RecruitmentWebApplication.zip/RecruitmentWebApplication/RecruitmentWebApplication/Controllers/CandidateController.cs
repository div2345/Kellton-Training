﻿using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using RecruitmentWebApplication.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Security.Cryptography;
using System.Text;

namespace RecruitmentWebApplication.Controllers
{
    public class CandidateController : Controller
    {
        string baseurl;
        UserModel userModel = new UserModel();

       // private readonly ISession session;



        private IHostingEnvironment _env;
        private string _dir;

        public CandidateController(IHostingEnvironment env)
        {
            _env = env;
            _dir = env.ContentRootPath;
        }
       
        public string UploadFile(IFormFile file)
        {
            string path;
            
            var fileExt = System.IO.Path.GetExtension(file.FileName).Substring(1);
            if (fileExt == "pdf" || fileExt == "doc")
            {
                if (file == null || file.Length == 0)
                {
                    return null;
                }
                using (var fileStream = new FileStream(Path.Combine(string.Concat(_dir, "/Resume"), file.FileName), FileMode.Create, FileAccess.Write))
                {
                    path = Path.Combine(string.Concat(_dir, "/Resume"), file.FileName);
                    file.CopyTo(fileStream);
                }
                // return fileStream;
                return path;
            }
            else
            {
                return null;
            }
        }


        private UserModel GetApIHit(string baseurl, string EncryptUserID, string tokent)
        {
            UserModel userModel = new UserModel();
            using (var client = new HttpClient())
            {
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", tokent);
                client.BaseAddress = new Uri(this.baseurl);
                var responseTask = client.GetAsync(requestUri: "?EncryptUserId=" + EncryptUserID);
                //var responseTask = client.PostAsJsonAsync(baseurl, EncryptUserID);
                responseTask.Wait();
                var result = responseTask.Result;
                if (result.StatusCode == System.Net.HttpStatusCode.OK)
                {
                    var readTask = result.Content.ReadAsAsync<UserModel>();
                    readTask.Wait();
                    userModel = readTask.Result;
                }
                else if(result.StatusCode == System.Net.HttpStatusCode.Unauthorized)
                {
                    userModel.Error = "Unauthorized";
                }
                else if (result.StatusCode == System.Net.HttpStatusCode.NoContent)
                {
                    userModel.Error = "No Content";
                }

                return userModel;
            }
           

        }

        private UserModel GetApIHit(string baseurl, int UserID, UserModel user, string tokent)
        {
            UserModel userModel = new UserModel();
            using (var client = new HttpClient())
            {
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", tokent);
                client.BaseAddress = new Uri(baseurl);
                if (user == null && UserID != 0)
                {
                    var responseTask = client.GetAsync(requestUri: "?UserID=" + UserID);
                    responseTask.Wait();
                    var result = responseTask.Result;
                    if (result.StatusCode == System.Net.HttpStatusCode.OK)
                    {
                        var readTask = result.Content.ReadAsAsync<UserModel>();
                        readTask.Wait();
                        userModel = readTask.Result;
                    }
                    else if (result.StatusCode == System.Net.HttpStatusCode.BadRequest)
                    {
                        userModel.Error = "Bad Request";
                    }
                    return userModel;
                }
                else
                {
                    var responseTask = client.PostAsJsonAsync(this.baseurl, user);
                    responseTask.Wait();
                    var result = responseTask.Result;
                    if (result.StatusCode == System.Net.HttpStatusCode.OK)
                    {
                        var readTask = result.Content.ReadAsAsync<UserModel>();
                        readTask.Wait();
                        userModel = readTask.Result;
                    }
                    else if(result.StatusCode == System.Net.HttpStatusCode.BadRequest)
                    {
                        userModel.Error = "Bad Request";
                    }
                    return userModel;
                }
            }
        }
        [HttpGet]
        public ActionResult Index(int UserID)
        {
            string UserIdString = HttpContext.Session.GetString("sessionForUserID");
            string EncryptUserID = Encrypt(UserIdString);
            var tokent = HttpContext.Session.GetString("sessionForToken");
            UserModel userModel = new UserModel();
            baseurl = "http://localhost:60574/api/Candidate/GetEmployee";
            userModel = GetApIHit(baseurl, EncryptUserID, tokent);
            if (userModel.Error == null)
                return View(userModel);
            else if (userModel.Error == "Unauthorized")
                return Content("UnAuthorized");
            else //if (userModel.Error == "No Content")
                return Content("No Content");

        }
        [HttpGet]
        public ActionResult Update(int UserID)
         {
            var tokent = HttpContext.Session.GetString("sessionForToken");
            UserModel userModel = new UserModel();
            baseurl = "http://localhost:60574/api/Candidate/GetEmployee";
          //  userModel = GetApIHit(baseurl, UserID, tokent);
            if (userModel.Error == null)
                return View(userModel);
            else
                return Content("Bad Request");
        }

        [HttpPost]
        public ActionResult Edit(int UserID, UserModel user, IFormFile files)
        {
            var tokent = HttpContext.Session.GetString("sessionForToken");
            UserModel userModel = new UserModel();
            if (files == null)
            {
                baseurl = "http://localhost:60574/api/Candidate/Update";
                userModel = GetApIHit(baseurl, UserID, user, tokent);
                if (userModel.Error == null)
                    return View(userModel);
                else
                    return Content("Bad Request");
            }
            else
            {
                string filepath = UploadFile(files);
                if (filepath == null)
                {
                    return Content("Upload resume into PDF or DOC format");
                }
                user.ResumeFileLocation = filepath;
                baseurl = "http://localhost:60574/api/Candidate/Update";
                userModel = GetApIHit(baseurl,UserID, user, tokent);
                if (userModel.Error == null)
                    return View(userModel);
                else
                    return Content("Bad Request");
            }
        }

        private string Encrypt(string clearText)
        {
            string EncryptionKey = "MAKV2SPBNI99212";
            byte[] clearBytes = Encoding.Unicode.GetBytes(clearText);
            using (Aes encryptor = Aes.Create())
            {
                Rfc2898DeriveBytes pdb = new Rfc2898DeriveBytes(EncryptionKey, new byte[] { 0x49, 0x76, 0x61, 0x6e, 0x20, 0x4d, 0x65, 0x64, 0x76, 0x65, 0x64, 0x65, 0x76 });
                encryptor.Key = pdb.GetBytes(32);
                encryptor.IV = pdb.GetBytes(16);
                using (MemoryStream ms = new MemoryStream())
                {
                    using (CryptoStream cs = new CryptoStream(ms, encryptor.CreateEncryptor(), CryptoStreamMode.Write))
                    {
                        cs.Write(clearBytes, 0, clearBytes.Length);
                        cs.Close();
                    }
                    clearText = Convert.ToBase64String(ms.ToArray());
                }
            }
            return clearText;
        }




    }
}