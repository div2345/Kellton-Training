﻿using Microsoft.AspNetCore.Mvc;
using RecruitmentWebApplication.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Net.Http;
using System.Text.RegularExpressions;

namespace RecruitmentWebApplication.Controllers
{
    public class TechnicalInterviewerController : Controller
    {

        string baseurl;
        private List<UserModel> GetApIHit(string baseurl, UserModel user)
        {
            List<UserModel> lstUserModel = new List<UserModel>();
            UserModel userModel = new UserModel();
            userModel.Error = string.Empty;
            if (user == null)
            {
                using (var client = new HttpClient())
                {
                    client.BaseAddress = new Uri(this.baseurl);
                    var responseTask = client.GetAsync(baseurl);
                    responseTask.Wait();
                    var result = responseTask.Result;
                    if (result.StatusCode == System.Net.HttpStatusCode.OK)
                    {
                        var readTask = result.Content.ReadAsAsync<List<UserModel>>();
                        readTask.Wait();
                        lstUserModel = readTask.Result;
                       
                    }
                    else if (result.StatusCode == System.Net.HttpStatusCode.Unauthorized)
                    {
                        userModel.Error = "Unauthorized";
                        lstUserModel.Add(userModel);

                    }

                }
                return lstUserModel;
            }
            else
            {
                using (var client = new HttpClient())
                {
                    client.BaseAddress = new Uri(this.baseurl);
                    var responseTask = client.PostAsJsonAsync(baseurl,user);
                    responseTask.Wait();
                    var result = responseTask.Result;
                    if (result.IsSuccessStatusCode)
                    {
                        var readTask = result.Content.ReadAsAsync<List<UserModel>>();
                        readTask.Wait();
                        lstUserModel = readTask.Result;
                    }
                    return lstUserModel;
                }
            }


        }

        private UserModel GetApIHit(string Baseurl, int UserID)
        {
            UserModel userModel = new UserModel();
            using (var client = new HttpClient())
            {

                client.BaseAddress = new Uri(Baseurl);
                var responseTask = client.GetAsync(requestUri: "?UserID=" + UserID);
                responseTask.Wait();
                var result = responseTask.Result;
                if (result.IsSuccessStatusCode)
                {
                    var readTask = result.Content.ReadAsAsync<UserModel>();
                    readTask.Wait();
                    userModel = readTask.Result;
                }
                return userModel;


            }
        }

        private string ApIHit(string baseurl, int UserID)
        {
            List<UserModel> userModel = new List<UserModel>();
            using (var client = new HttpClient())
            {
                string resume = string.Empty;
                client.BaseAddress = new Uri(this.baseurl);
                var responseTask = client.GetAsync(requestUri: "?UserID=" + UserID);
                responseTask.Wait();
                var result = responseTask.Result;
                if (result.StatusCode == System.Net.HttpStatusCode.OK)
                {
                    var readTask = result.Content.ReadAsStringAsync();
                    readTask.Wait();
                    resume = readTask.Result;
                    return resume;
                }
                else
                {
                    resume = "No Resume Found";
                    return resume;
                }
               
            }

        }

        public ActionResult  Index(int UserID)
        {
            List<UserModel> userModel = new List<UserModel>();
            baseurl = "http://localhost:60574/api/TechinalInterviewer/GetDetail";
            userModel = GetApIHit(baseurl,null);
            
            return View(userModel);          
        }
        [HttpGet]
        public ActionResult MarksValuation(int UserID)
        {
            UserScoreView userScore = new UserScoreView();
            return View(userScore);
        }
        [HttpPost]
        public ActionResult <int> MarksValuation(UserScoreView userScore)
        {
            List<UserScoreView> userscore = new List<UserScoreView>();
            baseurl = "http://localhost:60574/api/TechinalInterviewer/MarksUpdate";

            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(this.baseurl);
                var responseTask = client.PostAsJsonAsync(baseurl, userScore);
                responseTask.Wait();
                var result = responseTask.Result;
                if (result.StatusCode == System.Net.HttpStatusCode.OK)
                {
                    var readTask = result.Content.ReadAsAsync<int>();
                    readTask.Wait();

                    return RedirectToAction("InterviewState", "TechnicalInterviewer", new { UserID = userScore.UserId });
                }
                else if(result.StatusCode == System.Net.HttpStatusCode.NoContent)
                {

                    return Content("Enter Valid Marks");
                }
            }
            return null;
        }
        public ActionResult InterviewState(int UserID)
        {
            baseurl = "http://localhost:60574/api/TechinalInterviewer/InterviewState";
            GetApIHit(baseurl, UserID);
            return RedirectToAction("Index");
        }

        //[HttpGet]
        //public ActionResult Delete(int UserID)
        //{
        //    UserModel userModel = new UserModel();
        //    baseurl = "http://localhost:60574/api/Candidate/GetEmployee";
        //    userModel = GetApIHit(baseurl, UserID);
        //    return View(userModel);
        //}

        //[HttpPost, ActionName("Delete")]
        //public ActionResult DeleteConfirmed(int UserID)
        //{
        //    baseurl = "http://localhost:60574/api/TechinalInterviewer/Delete";
        //    GetApIHit(baseurl, UserID);
        //    return RedirectToAction("Index");
        //}

        public ActionResult DownloadFile(int UserID)
        {
            baseurl = "http://localhost:60574/api/TechinalInterviewer/Resume";
            string path = ApIHit(baseurl,UserID);
            if (path == "No Resume Found")
            {
                return Content("No Resume Found");
            }
            else
            {
                FileInfo fileInfo = new FileInfo(path);
                byte[] fileBytes = System.IO.File.ReadAllBytes(path);
                return File(fileBytes, System.Net.Mime.MediaTypeNames.Application.Pdf,fileInfo.Name);
            }
        }
        public ActionResult LogOut()
        {
            return RedirectToAction("login", "Account");
        }
    }
}




