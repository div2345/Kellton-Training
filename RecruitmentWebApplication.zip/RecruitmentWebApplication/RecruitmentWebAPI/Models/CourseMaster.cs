﻿using System;
using System.Collections.Generic;

namespace RecruitmentWebAPI.Models
{
    public partial class CourseMaster
    {
        public CourseMaster()
        {
            UserScore = new HashSet<UserScore>();
        }

        public int CourseId { get; set; }
        public string CourseName { get; set; }

        public virtual ICollection<UserScore> UserScore { get; set; }
    }
}
