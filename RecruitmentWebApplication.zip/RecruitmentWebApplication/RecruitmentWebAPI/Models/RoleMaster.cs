﻿using System;
using System.Collections.Generic;

namespace RecruitmentWebAPI.Models
{
    public partial class RoleMaster
    {
        public RoleMaster()
        {
            UserDetails = new HashSet<UserDetails>();
        }

        public int RoleId { get; set; }
        public string RoleName { get; set; }

        public virtual ICollection<UserDetails> UserDetails { get; set; }
    }
}
