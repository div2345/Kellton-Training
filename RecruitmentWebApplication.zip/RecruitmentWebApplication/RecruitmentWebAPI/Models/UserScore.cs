﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace RecruitmentWebAPI.Models
{
    public partial class UserScore
    {
        public int UserScoreId { get; set; }
        public int UserId { get; set; }
        public int CourseId { get; set; }
        [Range(1, 99, ErrorMessage = "Range Must be between 1 to 99")]
        public int Marks { get; set; }

        public virtual CourseMaster Course { get; set; }
        public virtual UserDetails User { get; set; }
    }
}
