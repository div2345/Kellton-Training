﻿using System;
using System.Collections.Generic;

namespace RecruitmentWebAPI.Models
{
    public partial class UserDetails
    {
        public UserDetails()
        {
            UserScore = new HashSet<UserScore>();
        }

        public int UserID { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
        public string PhoneNo { get; set; }
        public string Password { get; set; }
        public string ResumeFileLocation { get; set; }
        public int InterviewState { get; set; }
        public int RoleId { get; set; }

        public virtual RoleMaster Role { get; set; }
        public virtual ICollection<UserScore> UserScore { get; set; }
    }
}
