﻿using Microsoft.AspNetCore.Mvc;
using RecruitmentWebAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;

namespace RecruitmentWebAPI.Controllers
{
    [Route("api/HR/[action]")]
    [ApiController]
    public class HRController : ControllerBase
    {
        RecruitmentContext recruitmentContext = new RecruitmentContext();
        public ActionResult<List<UserDetails>> GetDetail()
        {
            List<UserDetails> lstUserDetails = new List<UserDetails>();
           // UserDetails userDetails = new UserDetails();

            lstUserDetails = recruitmentContext.UserDetails.Where(x => x.InterviewState == 1 && x.RoleId == 1).ToList();
            if (lstUserDetails.Count != 0)
            {
                return Ok(lstUserDetails);
            }
            else
            {
                return NoContent();
            }
        }
        public ActionResult <List<UserScoreView>> ShowResult(int UserID)
        {
            List<UserScoreView> userScoreViewlst = new List<UserScoreView>();
             UserScoreView userScoreView = new UserScoreView();
           
            var query = (from post in recruitmentContext.UserScore
                        join meta in recruitmentContext.CourseMaster on post.CourseId equals meta.CourseId
                        where post.UserId == UserID
                        select new { Post = post, Meta = meta }).ToList();


            userScoreView.UserId = UserID;

            foreach (var item in query)
            {
                userScoreView = new UserScoreView();
                userScoreView.UserId = Convert.ToInt32(item.Post.UserId);
                userScoreView.Marks = Convert.ToInt32(item.Post.Marks);
                userScoreView.CourseName= (item.Meta.CourseName.ToString());
                userScoreViewlst.Add(userScoreView);
            }
            return userScoreViewlst;

        }
    }
}