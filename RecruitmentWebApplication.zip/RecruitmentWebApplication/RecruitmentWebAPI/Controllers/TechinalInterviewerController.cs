﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RecruitmentWebAPI.Models;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;

namespace RecruitmentWebAPI.Controllers
{
    [Route("api/TechinalInterviewer/[action]")]
    [ApiController]
    //[Authorize]
    public class TechinalInterviewerController : ControllerBase
    {
        RecruitmentContext recruitmentContext = new RecruitmentContext();
        public ActionResult<List<UserDetails>> GetDetail()
        {

            List<UserDetails> userDetails = new List<UserDetails>();
            UserDetails usr = new UserDetails();

            userDetails = recruitmentContext.UserDetails.Where(x => x.RoleId == 1).ToList();
            if (userDetails.Count != 0)
            {
                return Ok(userDetails);
            }
            else
            {
                return NoContent();
            }

        }
        public ActionResult <string> Resume(int UserID)
        {
            string usr = string.Empty;
            var details = (from user1 in recruitmentContext.UserDetails
                           where user1.UserID == UserID 
                           select new { user1.ResumeFileLocation }).FirstOrDefault();
            if (details.ResumeFileLocation != null)
            {
                usr = details.ResumeFileLocation.ToString();
                return Ok(usr);
            }
            else
                return NoContent();
        }
        public ActionResult<int> MarksUpdate(UserScoreView score)
        {
            
            if (score.CourseIdList.Count != 0 && score.CourseIdList.Count != 0)
            {
                int count = score.CourseIdList.Count;
                for (int i = 0; i < count; i++)
                {
                    SqlParameter[] parameters = new SqlParameter[3];
                    parameters[0] = new SqlParameter("@UserID", score.UserId);
                    parameters[1] = new SqlParameter("@CourseID", score.CourseIdList[i]);
                    parameters[2] = new SqlParameter("@Marks", score.MarksList[i]);
                    recruitmentContext.Database.ExecuteSqlCommand("dbo.USP_InsertScore @UserID,@CourseID,@Marks", parameters);
                }
                return score.UserId;
            }
            else
            {
                return NoContent();
            }
        }
        public ActionResult InterviewState(int UserID)
        {
            SqlParameter[] parameters = new SqlParameter[1];
            parameters[0] = new SqlParameter("@UserID",UserID);
            recruitmentContext.Database.ExecuteSqlCommand("dbo.USP_UpdateInterviewState @UserID", parameters);
            return null;
        }

        public ActionResult Delete(int UserID)
        {
            SqlParameter[] parameters = new SqlParameter[1];
            parameters[0] = new SqlParameter("@UserID", UserID);
            recruitmentContext.Database.ExecuteSqlCommand("dbo.USP_DeleteUserScore @UserID", parameters);

            UserDetails userDetails = recruitmentContext.UserDetails.Find(UserID);
            if (userDetails != null)
            {
                recruitmentContext.Remove(userDetails);
                recruitmentContext.SaveChanges();
            }
            return null;
        }
    }
}