﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using RecruitmentWebAPI.Models;
using System;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Text;

namespace RecruitmentWebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [AllowAnonymous]
    public class AuthorizationController : ControllerBase
    {
        RecruitmentContext recruitmentContext = new RecruitmentContext();
       

        private IConfiguration _config;

        public AuthorizationController(IConfiguration config)
        {
            _config = config;
        }
        [HttpPost("token")]
        
        public ActionResult GetToken([FromBody] UserDetails login)
        {
            IActionResult response = Unauthorized();
            UserDetails user = AuthenticateUser(login);

            string securityKey = "this_is_our_supper_long_security_key_for_token_validation_$divyansh";
            var symmetricSecurityKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(securityKey));
            var signingCredentials = new SigningCredentials(symmetricSecurityKey, SecurityAlgorithms.HmacSha256Signature);
            JwtSecurityToken token;

            if (user.UserID != 0)
            {
                token = new JwtSecurityToken(
                    issuer: "divyansh",
                    audience: "readers",
                    expires: DateTime.Now.AddHours(1),
                    signingCredentials: signingCredentials
                );
            }
            else
            {
                token = new JwtSecurityToken(
                   issuer: "divyansh-fail",
                   audience: "readers",
                   expires: DateTime.Now,
                   signingCredentials: signingCredentials
               );
            }
            return Ok(new JwtSecurityTokenHandler().WriteToken(token));
        }

        private UserDetails AuthenticateUser(UserDetails login)
        {
            UserDetails user = new UserDetails() {
                UserID = 0
            };
             var details = (from user1 in recruitmentContext.UserDetails
                           where user1.Email == login.Email
                           select new { user1.UserID, user1.RoleId, user1.Name, user1.Password, user1.Email }).FirstOrDefault();
            if (details == null)
            {
                return user;
            }
            else
            {
                if (login.Email == details.Email)
                {
                    user = new UserDetails { Email = details.Email, Password = details.Password, UserID = details.UserID };
                }
                return user;
            }
        }
    }
}