﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using RecruitmentWebAPI.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;

namespace RecruitmentWebAPI.Controllers
{
    [Route("api/Account/[action]")]
    [ApiController]
    [Authorize]
    public class AccountController : ControllerBase
    {
        RecruitmentContext recruitmentContext = new RecruitmentContext();
        //[Authorize]
        public ActionResult <UserDetails> Login(UserDetails user)
        {
            List<string> errors = new List<string>();
            var details = (from user1 in recruitmentContext.UserDetails
                           where user1.Email == user.Email 
                           select new { user1.UserID, user1.RoleId, user1.Name, user1.Password, user1.Email }).FirstOrDefault();
            
            if (details == null)
            {
                return BadRequest();
            }
            else
            {
                var pass = Decrypt(details.Password);

                if (pass == user.Password)
                {
                    UserDetails userDetails = new UserDetails();
                    
                        userDetails.RoleId = details.RoleId;
                        userDetails.UserID = details.UserID;
                        userDetails.Name = details.Name;
                        return Ok(userDetails);
                }
                else
                {
                    return BadRequest();
                }
            }
        }
        [AllowAnonymous]
        public ActionResult <UserDetails> Register(UserDetails user)
        {
            if (ModelState.IsValid)
            {
                if (recruitmentContext.UserDetails.Where( x => x.Email == user.Email ).Count() > 0 )
                {
                    return BadRequest();
                }
                else
                {
                    recruitmentContext.UserDetails.Add(user);
                    recruitmentContext.SaveChanges();
                    return Ok(user);
                }
            }
            else
            {
                //ModelState.AddModelError(string.Empty, "Model State Error");
                return null;
            }
        }

        private string Decrypt(string cipherText)
        {
            string EncryptionKey = "MAKV2SPBNI99212";
            byte[] cipherBytes = Convert.FromBase64String(cipherText);
            using (Aes encryptor = Aes.Create())
            {
                Rfc2898DeriveBytes pdb = new Rfc2898DeriveBytes(EncryptionKey, new byte[] { 0x49, 0x76, 0x61, 0x6e, 0x20, 0x4d, 0x65, 0x64, 0x76, 0x65, 0x64, 0x65, 0x76 });
                encryptor.Key = pdb.GetBytes(32);
                encryptor.IV = pdb.GetBytes(16);
                using (MemoryStream ms = new MemoryStream())
                {
                    using (CryptoStream cs = new CryptoStream(ms, encryptor.CreateDecryptor(), CryptoStreamMode.Write))
                    {
                        cs.Write(cipherBytes, 0, cipherBytes.Length);
                        cs.Close();
                    }
                    cipherText = Encoding.Unicode.GetString(ms.ToArray());
                }
            }
            return cipherText;
        }
    }
}
