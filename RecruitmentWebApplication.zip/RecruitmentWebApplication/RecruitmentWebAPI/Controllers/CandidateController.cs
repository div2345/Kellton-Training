﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using RecruitmentWebAPI.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;

namespace RecruitmentWebAPI.Controllers
{
    [Route("api/Candidate/[action]")]
    [ApiController]
    [Authorize]
    public class CandidateController : ControllerBase
    {
        RecruitmentContext recruitmentContext = new RecruitmentContext();

        [HttpGet]
        public ActionResult <UserDetails> GetEmployee(string EncryptUserId)
        {
            string Uid = Decrypt(EncryptUserId);
            int UserID = Int32.Parse(Uid);
           // Int32.TryParse(Uid.Text, out UserID);
            UserDetails userDetails;
            var candidate = (from user1 in recruitmentContext.UserDetails
                           where user1.UserID == UserID
                           select new { user1.UserID, user1.RoleId}).FirstOrDefault();

            if (UserID != 0 && candidate.RoleId == 1)
            {
                userDetails = new UserDetails();
                userDetails = recruitmentContext.UserDetails.Find(UserID);
                return Ok(userDetails);
            }
            else
                return NoContent();
        }

        public ActionResult<UserDetails> Update(int UserID, UserDetails candidateChanges)
        {
            if (candidateChanges.Password != null &&candidateChanges.Name != null && candidateChanges.PhoneNo !=null  && candidateChanges.Email != null )
            {
                var employee = recruitmentContext.Attach(candidateChanges);
                employee.State = Microsoft.EntityFrameworkCore.EntityState.Modified;
                recruitmentContext.SaveChanges();
                return Ok(candidateChanges);
            }
            else
                return BadRequest();
        }

        private string Decrypt(string EncryptUserId)
        {
            string EncryptionKey = "MAKV2SPBNI99212";
            byte[] cipherBytes = Convert.FromBase64String(EncryptUserId);
            using (Aes encryptor = Aes.Create())
            {
                Rfc2898DeriveBytes pdb = new Rfc2898DeriveBytes(EncryptionKey, new byte[] { 0x49, 0x76, 0x61, 0x6e, 0x20, 0x4d, 0x65, 0x64, 0x76, 0x65, 0x64, 0x65, 0x76 });
                encryptor.Key = pdb.GetBytes(32);
                encryptor.IV = pdb.GetBytes(16);
                using (MemoryStream ms = new MemoryStream())
                {
                    using (CryptoStream cs = new CryptoStream(ms, encryptor.CreateDecryptor(), CryptoStreamMode.Write))
                    {
                        cs.Write(cipherBytes, 0, cipherBytes.Length);
                        cs.Close();
                    }
                    EncryptUserId = Encoding.Unicode.GetString(ms.ToArray());
                }
            }
            return EncryptUserId;
        }
    }
}